const mongoose = require("mongoose");

const PdfDetailsSchema = new mongoose.Schema(
  {
    title: String,
    content: Buffer,
  },
  { collection: "PdfDetails" }
);

mongoose.model("PdfDetails", PdfDetailsSchema);
